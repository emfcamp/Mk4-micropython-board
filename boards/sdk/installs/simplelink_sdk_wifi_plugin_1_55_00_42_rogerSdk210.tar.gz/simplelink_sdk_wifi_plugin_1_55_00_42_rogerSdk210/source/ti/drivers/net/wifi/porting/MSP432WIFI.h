/*
 *   Copyright (C) 2017 Texas Instruments Incorporated
 *
 *   All rights reserved. Property of Texas Instruments Incorporated.
 *   Restricted rights to use, duplicate or disclose this code are
 *   granted through contract.
 *
 *   The program may not be used without the written permission of
 *   Texas Instruments Incorporated or against the terms and conditions
 *   stipulated in the agreement under which this program has been supplied,
 *   and under no circumstances can it be used with non-TI connectivity device.
 *
 */
/******************************************************************************
*     msp432.h
*
*    Simplelink Wi-Fi platform specific information for MSP432P4 and MSP432E4
******************************************************************************/
#ifndef __SIMPLELINK_MSP432P4_H__
#define __SIMPLELINK_MSP432P4_H__

#ifdef  __cplusplus
extern "C" {
#endif

#include <ti/drivers/net/wifi/porting/cc_pal.h>

typedef struct WIFIMSP432_HWAttrsV1
{
    uint_least8_t spiIndex;         /* Index of the SPI driver to use */
    uint_least8_t hostIRQPin;       /* Host IRQ Pin */
    uint_least8_t nHIBPin;          /* nHIBPint */
    uint_least8_t csPin;            /* Chip Select Pin */
    uint_least16_t maxDMASize;      /* Maximum DMA size (default 1024) */
    uint32_t spiBitRate;            /* Bitrate of SPI */
} WIFIMSP432_HWAttrsV1;

#define ASSERT_CS()         (GPIO_write(curDeviceConfiguration->csPin, 0))
#define DEASSERT_CS()       (GPIO_write(curDeviceConfiguration->csPin, 1))

#ifdef  __cplusplus
}
#endif

#endif /*__SIMPLELINK_MSP432P4_H__*/
