/*
 *   Copyright (C) 2015 Texas Instruments Incorporated
 *
 *   All rights reserved. Property of Texas Instruments Incorporated.
 *   Restricted rights to use, duplicate or disclose this code are
 *   granted through contract.
 *
 *   The program may not be used without the written permission of
 *   Texas Instruments Incorporated or against the terms and conditions
 *   stipulated in the agreement under which this program has been supplied,
 *   and under no circumstances can it be used with non-TI connectivity device.
 *
 */
/******************************************************************************
*     msp_pal.c
*
*    Simplelink Wi-Fi platform abstraction file for MSP432
******************************************************************************/
#include <ti/drivers/SPI.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/net/wifi/porting/cc_pal.h>
#include <ti/drivers/net/wifi/porting/MSP432WIFI.h>
#include <ti/drivers/net/wifi/simplelink.h>

/****************************************************************************
   GLOBAL VARIABLES
****************************************************************************/
volatile Fd_t g_SpiFd = 0;
SL_P_EVENT_HANDLER g_Host_irq_Hndlr = NULL;

/****************************************************************************
   CONFIGURATION VARIABLES
****************************************************************************/
extern const WiFi_Config WiFi_config[];
extern const uint_least8_t WiFi_count;
static WIFIMSP432_HWAttrsV1* curDeviceConfiguration;

/****************************************************************************
   CONFIGURATION FUNCTION DEFINITION
****************************************************************************/
void WiFi_init()
{
    /* We need to have at least one WiFi module. */
    if(WiFi_count == 0)
    {
        return;
    }

    curDeviceConfiguration = (WIFIMSP432_HWAttrsV1*) WiFi_config[0].hwAttrs;
}

/****************************************************************************
   LOCAL FUNCTION DEFINITIONS
****************************************************************************/
Fd_t spi_Open(char *ifName,
              unsigned long flags)
{
    void *lspi_hndl;
    SPI_Params SPI_Config;

    /* Initialize the WiFi driver */
    WiFi_init();

    /* If we could not initialize the device bail out with an error code */
    if(curDeviceConfiguration == NULL)
    {
        return (-1);
    }

    /* Initialize the SPI config structure */
    SPI_Params_init(&SPI_Config);
    SPI_Config.transferMode = SPI_MODE_BLOCKING;
    SPI_Config.mode = SPI_MASTER;
    SPI_Config.bitRate = curDeviceConfiguration->spiBitRate;
    SPI_Config.dataSize = 8;
    SPI_Config.frameFormat = SPI_POL0_PHA0;

    /* Open SPI interface with SPI_Config parameters */
    lspi_hndl = SPI_open(curDeviceConfiguration->spiIndex, &SPI_Config);

    if(NULL == lspi_hndl)
    {
        return (-1);
    }
    else
    {
        return ((Fd_t) lspi_hndl);
    }
}

int spi_Close(Fd_t fd)
{
    SPI_close((void *) fd);
    return (0);
}

int spi_Read(Fd_t fd,
             unsigned char *pBuff,
             int len)
{
    SPI_Transaction transact_details;
    int read_size = 0;

    ASSERT_CS();

    /* check if the link SPI has been initialized successfully */
    if(fd < 0)
    {
        DEASSERT_CS();
        return (-1);
    }

    transact_details.txBuf = NULL;
    transact_details.arg = NULL;
    transact_details.rxBuf = (void*) (pBuff);

    while(len > 0)
    {
        if(len > curDeviceConfiguration->maxDMASize)
        {
            transact_details.count = curDeviceConfiguration->maxDMASize;
        }
        else
        {
            transact_details.count = len;
        }

        if(SPI_transfer((SPI_Handle) fd, &transact_details))
        {
            read_size += transact_details.count;
            len = len - transact_details.count;
            transact_details.rxBuf = ((unsigned char *) (transact_details.rxBuf)
                                      + read_size);
        }
        else
        {
            DEASSERT_CS();
            return (-1);
        }
    }

    DEASSERT_CS();

    return (read_size);
}

int spi_Write(Fd_t fd,
              unsigned char *pBuff,
              int len)
{
    SPI_Transaction transact_details;
    int write_size = 0;

    ASSERT_CS();

    /* check if the link SPI has been initialized successfully */
    if(fd < 0)
    {
        DEASSERT_CS();
        return (-1);
    }

    transact_details.rxBuf = NULL;
    transact_details.arg = NULL;
    transact_details.txBuf = (void*) (pBuff);

    while(len > 0)
    {
        if(len > curDeviceConfiguration->maxDMASize)
        {
            transact_details.count = curDeviceConfiguration->maxDMASize;
        }
        else
        {
            transact_details.count = len;
        }

        if(SPI_transfer((SPI_Handle) fd, &transact_details))
        {
            write_size += transact_details.count;
            len = len - transact_details.count;
            transact_details.txBuf = ((unsigned char *) (transact_details.txBuf)
                                      + transact_details.count);
        }
        else
        {
            DEASSERT_CS();
            return (-1);
        }
    }

    DEASSERT_CS();

    return (write_size);
}

int NwpRegisterInterruptHandler(P_EVENT_HANDLER InterruptHdl,
                                void* pValue)
{
    /* Check for unregister condition */
    if(NULL == InterruptHdl)
    {
        GPIO_disableInt(curDeviceConfiguration->hostIRQPin);
        GPIO_clearInt(curDeviceConfiguration->hostIRQPin);
        g_Host_irq_Hndlr = NULL;
        return (0);
    }
    else if(NULL == g_Host_irq_Hndlr)
    {
        g_Host_irq_Hndlr = InterruptHdl;
        GPIO_setCallback(curDeviceConfiguration->hostIRQPin,
                         HostIrqGPIO_callback);
        GPIO_clearInt(curDeviceConfiguration->hostIRQPin);
        GPIO_enableInt(curDeviceConfiguration->hostIRQPin);
        return (0);
    }
    else
    {
        /* An error occurred */
        return (-1);
    }
}

void HostIrqGPIO_callback(uint_least8_t index)
{
    if((index == curDeviceConfiguration->hostIRQPin)
       && (NULL != g_Host_irq_Hndlr))
    {
        g_Host_irq_Hndlr(0);
    }
}

void NwpMaskInterrupt()
{
}

void NwpUnMaskInterrupt()
{
}

void NwpPowerOnPreamble(void)
{
    /* Maybe start timer here? */
}

void NwpPowerOn(void)
{
    GPIO_write(curDeviceConfiguration->nHIBPin, 1);
    /* wait 5msec */
    ClockP_usleep(5000);
}

void NwpPowerOff(void)
{
    GPIO_write(curDeviceConfiguration->nHIBPin, 0);
    /* wait 5msec */
    ClockP_usleep(5000);
}

int Semaphore_create_handle(SemaphoreP_Handle* pSemHandle)
{
    SemaphoreP_Params params;

    SemaphoreP_Params_init(&params);
    params.mode = SemaphoreP_Mode_BINARY;
#ifndef SL_PLATFORM_MULTI_THREADED
    params.callback = tiDriverSpawnCallback;
#endif
    (*(pSemHandle)) = SemaphoreP_create(1, &params);

    if(!(*(pSemHandle)))
    {
		return Semaphore_FAILURE ;
    }

	return Semaphore_OK;
}

int SemaphoreP_delete_handle(SemaphoreP_Handle* pSemHandle)
{
    SemaphoreP_delete(*(pSemHandle));
    return Semaphore_OK;
}

int SemaphoreP_post_handle(SemaphoreP_Handle* pSemHandle)
{
    SemaphoreP_post(*(pSemHandle));
    return Semaphore_OK;
}

int Mutex_create_handle(MutexP_Handle* pMutexHandle)
{
    MutexP_Params params;

    MutexP_Params_init(&params);
#ifndef SL_PLATFORM_MULTI_THREADED
    params.callback = tiDriverSpawnCallback;
#endif

    (*(pMutexHandle)) = MutexP_create(&params);

    if(!(*(pMutexHandle)))
    {
		return Mutex_FAILURE ;
    }

	return Mutex_OK;
}

int MutexP_delete_handle(MutexP_Handle* pMutexHandle)
{
    MutexP_delete(*(pMutexHandle));
    return(Mutex_OK);
}

int Mutex_unlock(MutexP_Handle pMutexHandle)
{
    MutexP_unlock(pMutexHandle, 0);
	return(Mutex_OK);
}

int Mutex_lock(MutexP_Handle pMutexHandle)
{
    MutexP_lock(pMutexHandle);
	return(Mutex_OK);
}

unsigned long TimerGetCurrentTimestamp()
{
    return (ClockP_getSystemTicks());
}
