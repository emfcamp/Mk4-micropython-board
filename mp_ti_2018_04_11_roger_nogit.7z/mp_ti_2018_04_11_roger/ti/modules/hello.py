print('hello, world')
