//#define SSID "TP-LINK_2AF1D2"
//#define SECURITY_KEY "HelloRomi2017"

//#define SSID "MGN6P"
//#define SECURITY_KEY "cmcusw_2017"

#define SSID "mjjp24"
#define SECURITY_KEY "ToGodBeTheGlory"

#define SECURITY_TYPE SL_WLAN_SEC_TYPE_WPA_WPA2
