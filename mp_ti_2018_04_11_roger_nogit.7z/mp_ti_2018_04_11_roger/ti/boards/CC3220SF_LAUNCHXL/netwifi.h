extern void NetWiFi_init(void);
