#ifndef MPCONFIBOARD_H_INC
#define MPCONFIBOARD_H_INC

#define MICROPY_HW_BOARD_NAME        "MSP_EXP432E401Y_CC3120"
#define MICROPY_HW_MCU_NAME          "TI MSP432E4"

//#define MICROPY_PY_NETWORK_NDK       (1)   /* TI NDK Ethernet */
#define MICROPY_PY_NETWORK_WIFI      (1)   /* TI WiFi */

#endif
