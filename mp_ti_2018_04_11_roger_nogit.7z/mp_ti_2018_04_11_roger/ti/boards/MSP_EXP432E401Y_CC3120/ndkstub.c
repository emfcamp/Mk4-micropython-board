#include <stdio.h>
#include <stdarg.h>

void NDK_hookInit(int32_t id)
{
}
